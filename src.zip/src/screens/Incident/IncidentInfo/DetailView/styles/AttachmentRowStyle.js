import {StyleSheet} from "react-native";
import color from '../../../../../constants/Color';
import size from '../../../../../constants/Size';

export default StyleSheet.create({
    attachmentRootStyle: {
        backgroundColor: color.PINK,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 5
    }, attachmentTextStyle: {
        color: color.WHITE,
        fontSize: size.FONT_SIZE_S,
        fontWeight: 'bold'
    }
})