module.exports = {
    OK: 200,
    BAD_REQUEST: 400,
    AUTHORIZATION_FAILED: 401,
    NOT_FOUND: 404,
    FORBIDDEN: 403
};