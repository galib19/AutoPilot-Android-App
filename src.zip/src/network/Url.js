//LOCAL PC
export const BASE_URL = 'http://172.16.231.179:8000/api/';
