module.exports = {
    NEW: 'New',
    ACKNOWLEDGED: 'Acknowledged',
    ASSIGNED: 'Assigned',
    IN_PROGRESS: 'In-Progress',
    COMPLETED: 'Completed',
    FAILED: 'Failed'
};