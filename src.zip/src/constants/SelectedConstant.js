module.exports = {
    SELECTED: 'isSelected',
    CHECKED: 'checked',
    TOTAL_COMMENT: 'total_comments'
};