module.exports = {
    ID: 'id',
    URI: 'uri',
    FILE_NAME: 'fileName',
    FILE_SIZE: 'fileSize'
};