module.exports = {
    MOBILE_NUMBER_PATTERN: "^01[15-9]\\d{8}$"
};