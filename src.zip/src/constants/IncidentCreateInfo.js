module.exports = {
    VICTIM_NAME: 'VICTIM_NAME',
    PAR_OR_HUS: 'PAR_OR_HUS',
    AGE: 'AGE',
    LOCATION: 'LOCATION',
    SELECT_GENDER: 'Select Gender',
    CASE_NAME: 'CASE_NAME',
    CASE_DETAILS: 'CASE_DETAILS',
    SELECT_VIOLENCE_TYPE: 'Select Violence Type',
    CASE_DATE: 'CASE_DATE',
    FILE_NAME_KEY: 'multi_files[]',
    ETA: 'ETA',
    ERT: 'ERT'
};