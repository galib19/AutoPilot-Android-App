module.exports = {
    FILE_NAME_KEY: 'profile_pic[]'
};